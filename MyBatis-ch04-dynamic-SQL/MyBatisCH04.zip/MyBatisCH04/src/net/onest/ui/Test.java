package net.onest.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import net.onest.entity.User;
import net.onest.mapper.UserMapper;
import net.onest.util.MyBatisUtil;

public class Test {

	public static void main(String[] args) {

		//��һ�ַ�ʽ����ͳ��ʽ��
		//��SqlSession
//		SqlSession sqlSession = MyBatisUtil.openSqlSession();
//		//����Ϊӳ���ļ��е�namespace+id
//		List<User> users = sqlSession.selectList("net.onest.mapper.UserMapper.findAllUsers");
//		
//		System.out.println(users);
//		//�ر�SqlSession
//		sqlSession.close();
		
		//�ڶ��ַ�ʽ���Ƽ�ʹ�ã�
		//��SqlSession
		SqlSession sqlSession = MyBatisUtil.openSqlSession();
		//�õ���ӳ�����ӿ�ʵ����Ķ���
		UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
//		List<User> users =  userMapper.findAllUsers();
//		System.out.println(users);
		
//		userMapper.findUserByNameAndPassword("����", "123");
		
//		Map<String, String> map = new HashMap<>();
////		map.put("phone", "1234567");
//		map.put("email", "test@163.com");
//		userMapper.findUserByPhoneOrEmail(map);
		
//		User u = new User();
//		u.setId(1);
//		u.setPhone("111111");
//		userMapper.updateUserByIdSelective(u);
		
//		User u = new User();
//		u.setUserName("hanmeimei");
//		userMapper.insertUser(u);
//		
//		sqlSession.commit();
		
//		List<Integer> ids  = new ArrayList<Integer>();
//		ids.add(1);
//		ids.add(2);
//		userMapper.findUsersByIdList(ids);
		
//		User u1 = new User();
//		u1.setUserName("tom");
//		List<User> users = new ArrayList<>();
//		users.add(u1);
//		users.add(u1);
//		
//		userMapper.insertUsers(users);
//		sqlSession.commit();
		
		Map<String, Object> map = new HashMap<>();
		map.put("id", 1);
		map.put("user_name", "zhangsan");
		userMapper.updateUserByMap(map);
		sqlSession.commit();
		
		//�ر�session
		sqlSession.close();
	}

}
