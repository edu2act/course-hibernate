package net.onest.server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import net.onest.server.entity.User;
import net.onest.server.service.UserService;

@Controller
@RequestMapping("user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@RequestMapping("getUsers")
	public ModelAndView getUsers() {
		ModelAndView mv = new ModelAndView("userList");
		List<User> users = userService.findAllUsers();
		mv.addObject("users", users);
		return mv;
	}
	
	@RequestMapping("addUser")
	public ModelAndView addUser() {
		ModelAndView mv = new ModelAndView("addUser");
		User u = new User();
		mv.addObject("user", u);
		return mv;
	}
	
	@RequestMapping("saveUser")
	public ModelAndView saveUser(User u) {
		userService.insertUser(u);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("redirect:/user/getUsers");
		return mv;
	}
}
