package net.onest.server.service;

import java.util.List;

import net.onest.server.entity.User;

public interface UserService {

	public List<User> findAllUsers();	
	public int insertUser(User u);
}
