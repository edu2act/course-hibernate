package net.onest.demo;

public interface Submitted {

	public void submitHomework();
}
