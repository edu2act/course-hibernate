package net.onest.demo;

public class Student implements Submitted{

	private String name;

	public Student(String name) {
		super();
		this.name = name;
	}

	@Override
	public void submitHomework() {
		System.out.println(name + "�ύ��ҵ");
	}
	
	
}
