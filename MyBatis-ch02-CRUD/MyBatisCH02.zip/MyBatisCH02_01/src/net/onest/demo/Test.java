package net.onest.demo;

public class Test {

	public static void main(String[] args) {
		Student stu = new Student("����");
		Monitor mon = new Monitor();
		mon.setStu(stu);
		
		submit(mon);
	}
	
	public static void submit(Submitted sub) {
		sub.submitHomework();
	}
}
