package net.onest.demo;

public class Monitor implements Submitted{

	private Student stu;
	
	public Student getStu() {
		return stu;
	}



	public void setStu(Student stu) {
		this.stu = stu;
	}



	@Override
	public void submitHomework() {
		System.out.println("��������淶");
		stu.submitHomework();
	}

}
