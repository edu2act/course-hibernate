package net.onest.mapper;

import java.util.List;

import net.onest.entity.User;

public interface UserMapper {

	public List<User> findAllUsers();
}
