package net.onest.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import net.onest.entity.User;

public interface UserMapper {

	public List<User> findAllUsers();
	
	public int findUserByUserName(@Param("name")String userName);
}
