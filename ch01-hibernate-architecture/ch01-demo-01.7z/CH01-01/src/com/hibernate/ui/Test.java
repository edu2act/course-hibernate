package com.hibernate.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.hibernate.entity.Customer;
import com.hibernate.util.DBUtil;

public class Test {

    public static void main(String[] args) {
        Customer customer = new Customer();
        customer.setId(1);
        customer.setName("张三");
        customer.setAge(20);
        customer.setSex(0);
//        updateCustomer(customer);
        
//        findCustomerByName("张三");
        deleteCustomer(customer);
    }
    public static void saveCustomer(Customer customer){
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt;
        try {
            pstmt = conn.prepareStatement("insert into customer(id,name,age,sex) values(?,?,?,?)");
            pstmt.setInt(1, customer.getId());
            pstmt.setString(2, customer.getName());
            pstmt.setInt(3, customer.getAge());
            pstmt.setInt(4, customer.getSex());
            int rs = pstmt.executeUpdate();
            
            System.out.println(rs);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    public static void deleteCustomer(Customer customer){
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt;
        try {
            pstmt = conn.prepareStatement("delete from customer where id=?");
            pstmt.setInt(1, customer.getId());
            int rs = pstmt.executeUpdate();
            
            System.out.println(rs);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public static void updateCustomer(Customer customer){
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt;
        try {
            pstmt = conn.prepareStatement("update customer set id=?,name=?,age=?,sex=?");
            pstmt.setInt(1, customer.getId());
            pstmt.setString(2, customer.getName());
            pstmt.setInt(3, customer.getAge());
            pstmt.setInt(4, customer.getSex());
            int rs = pstmt.executeUpdate();
            
            System.out.println(rs);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    public static Customer loadCustomer(Integer id){
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt;
        Customer cus = new Customer();
        try {
            pstmt = conn.prepareStatement("select * from customer where id = ?");
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                cus.setId(rs.getInt("id"));
                cus.setName(rs.getString("name"));
                cus.setAge(rs.getInt("age"));
                cus.setSex(rs.getInt("sex"));
                System.out.println(cus.getName());
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return cus;
    }
    public static List findCustomerByName(String name){
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt;
        List cusList = new ArrayList<Customer>();
        Customer cus = new Customer();
        try {
            pstmt = conn.prepareStatement("select * from customer where name = ?");
            pstmt.setString(1, name);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                cus.setId(rs.getInt("id"));
                cus.setName(rs.getString("name"));
                cus.setAge(rs.getInt("age"));
                cus.setSex(rs.getInt("sex"));
                cusList.add(cus);
                System.out.println(cus.getName());
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return cusList;
    }
    public static List findCustomerByAge(int age){
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt;
        List cusList = new ArrayList<Customer>();
        Customer cus = new Customer();
        try {
            pstmt = conn.prepareStatement("select * from customer where age = ?");
            pstmt.setInt(1, age);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                cus.setId(rs.getInt("id"));
                cus.setName(rs.getString("name"));
                cus.setAge(rs.getInt("age"));
                cus.setSex(rs.getInt("sex"));
                cusList.add(cus);
                System.out.println(cus.getName());
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return cusList;
    }
    public static List findCustomerByNameAndAge(String name, int age){
        Connection conn = DBUtil.getConnection();
        PreparedStatement pstmt;
        List cusList = new ArrayList<Customer>();
        Customer cus = new Customer();
        try {
            pstmt = conn.prepareStatement("select * from customer where name = ? and age = ?");
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                cus.setId(rs.getInt("id"));
                cus.setName(rs.getString("name"));
                cus.setAge(rs.getInt("age"));
                cus.setSex(rs.getInt("sex"));
                cusList.add(cus);
                System.out.println(cus.getName());
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return cusList;
    }

}
