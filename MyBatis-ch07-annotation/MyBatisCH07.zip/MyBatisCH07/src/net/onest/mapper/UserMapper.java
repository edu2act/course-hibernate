package net.onest.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import net.onest.entity.User;

public interface UserMapper {

//	@Select("select id, user_name userName, password from user")
	@Results(id="userMap", value={
		@Result(column="id", property="id", id=true),
		@Result(column="user_name", property="userName"),
		@Result(column="password", property="password")
	})
	@Select("select * from user")
	public List<User> findAllUsers();
	
	//ͨ��id��ֵ���ö���õ�Results
    @ResultMap("userMap")	
    @Select("select * from user where id = #{id}")
	public User findUserById(int id);
   
    @Insert("insert into user(user_name,password) "
    		+ "values(#{userName},#{password})")
    @Options(useGeneratedKeys=true, keyProperty="id")
    public int insertUser(User u);
    
    @Update("update user set password = #{password} "
    		+ "where id = #{id}")
    public int updateUser(User u);
    
    @Delete("delete from user where id = #{id}")
    public int deleteUser(int id);
}
