package net.onest.mapper;

import java.util.List;

import net.onest.entity.Employee;

public interface EmployeeMapper {

	public List<Employee> findAllEmployee();
}
