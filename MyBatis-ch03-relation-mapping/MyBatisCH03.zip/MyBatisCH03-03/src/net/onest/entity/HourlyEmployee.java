package net.onest.entity;

public class HourlyEmployee extends Employee {

	private double rate;

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "HourlyEmployee [rate=" + rate + "]";
	}


	
}
