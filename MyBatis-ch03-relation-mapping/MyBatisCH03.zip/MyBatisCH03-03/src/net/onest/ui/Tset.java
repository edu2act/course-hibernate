package net.onest.ui;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import net.onest.mapper.EmployeeMapper;
import net.onest.util.MyBatisUtil;

public class Tset {

	public static void main(String[] args) {

		SqlSession session = MyBatisUtil.openSqlSession();
		EmployeeMapper mapper = session.getMapper(EmployeeMapper.class);
		System.out.println(mapper.findAllEmployee());
		
		session.close();
	}

}
