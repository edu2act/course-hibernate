package net.onest.entity;

public class ShoppingCart {

	private int id;
	private double price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "ShoppingCart [id=" + id + ", price=" + price + "]";
	}
	
	
}
