package net.onest.mapper;

public interface ShoppingCartMapper {

}
