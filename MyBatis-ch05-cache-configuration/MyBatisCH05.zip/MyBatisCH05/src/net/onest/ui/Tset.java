package net.onest.ui;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import net.onest.entity.User;
import net.onest.mapper.OrderMapper;
import net.onest.mapper.UserMapper;
import net.onest.util.MyBatisUtil;

public class Tset {

	public static void main(String[] args) {

		SqlSession session1 = MyBatisUtil.openSqlSession();
		UserMapper userMapper = session1.getMapper(UserMapper.class);
		System.out.println(userMapper.findUserAndOrdersById(1));
//		System.out.println(userMapper.findUserById(1));
		//��ջ���
//		session1.clearCache();
//		User u = new User();
//		u.setId(1);
//		u.setPassword("111111");
//		userMapper.updateUserById(u);
//		session1.commit();
////		System.out.println(userMapper.findUserById(1));
		
		session1.close();
		
		SqlSession session2 = MyBatisUtil.openSqlSession();
//		UserMapper userMapper2 = session2.getMapper(UserMapper.class);
//		System.out.println(userMapper2.findUserById(1));
		
		OrderMapper orderMapper = session2.getMapper(OrderMapper.class);
		orderMapper.deleteOrderById(4);
		session2.commit();
		session2.close();
		
		SqlSession session3 = MyBatisUtil.openSqlSession();
		UserMapper userMapper2 = session3.getMapper(UserMapper.class);
		System.out.println(userMapper2.findUserAndOrdersById(1));
		session3.close();
	}

}
