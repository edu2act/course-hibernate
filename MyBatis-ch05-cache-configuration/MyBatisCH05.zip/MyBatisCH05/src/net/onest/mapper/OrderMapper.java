package net.onest.mapper;

public interface OrderMapper {

	public int deleteOrderById(int id);
}
